const fs = require('fs');
const os = require('os');
const path = require('path');
const url = require('url');
const events = require('events');


const filePath = path.join(__dirname, 'arquivo.txt');


const eventEmitter = new events.EventEmitter();

function exibirInfoSistema() {
    console.log('--- Informações do Sistema ---');
    console.log(`Sistema Operacional: ${os.type()}`);
    console.log(`Plataforma: ${os.platform()}`);
    console.log(`Arquitetura: ${os.arch()}`);
    console.log(`Memória Total: ${(os.totalmem() / 1024 / 1024).toFixed(2)} MB`);
    console.log(`Memória Livre: ${(os.freemem() / 1024 / 1024).toFixed(2)} MB`);
    console.log('--------------------------------\n');
}

function exibirInfoArquivo() {
    fs.stat(filePath, (err, stats) => {
        if (err) {
            console.log('Erro ao acessar arquivo:', err.message);
            return;
        }
        console.log('--- Informações do Arquivo ---');
        console.log(`Caminho: ${filePath}`);
        console.log(`Tamanho: ${stats.size} bytes`);
        console.log(`Última modificação: ${stats.mtime}`);
        console.log('--------------------------------\n');
    });
}

fs.watch(filePath, (eventType) => {
    console.log(`Alteração detectada: ${eventType}`);
    eventEmitter.emit('arquivoAlterado');
});


eventEmitter.on('arquivoAlterado', () => {
    exibirInfoSistema();
    exibirInfoArquivo();
});

console.log(`Monitorando alterações no arquivo: ${filePath}`);
