const fs = require('fs');
const os = require('os');
const path = require('path');
const url = require('url');
const readline = require('readline');
const events = require('events');

const filePath = path.join(__dirname, 'urls.json');
const eventEmitter = new events.EventEmitter();


if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify([]));
}

function carregarURLs() {
    return JSON.parse(fs.readFileSync(filePath));
}

function salvarURLs(urls) {
    fs.writeFileSync(filePath, JSON.stringify(urls, null, 2));
}

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function menu() {
    console.log('\n--- MENU ---');
    console.log('1 - Cadastrar URL');
    console.log('2 - Listar URLs');
    console.log('3 - Excluir URL');
    console.log('4 - Sair');
    rl.question('Escolha uma opção: ', opcao => {
        switch (opcao) {
      case '1':
         rl.question('Digite a URL: ', entrada => {
               try {
                 const novaURL = new url.URL(entrada);
                 const urls = carregarURLs();
                urls.push(novaURL.href);
                salvarURLs(urls);
                   console.log('✅ URL adicionada com sucesso!');
                   eventEmitter.emit('alteracao');
                   menu();
               } catch (err) {
                 console.log('❌ URL inválida!');
                  menu();
               }
                });
                break;
    case '2':
          console.log('\n--- URLs Cadastradas ---');
         const urls = carregarURLs();
         if (urls.length === 0) console.log('Nenhuma URL cadastrada.');
          else urls.forEach((u, i) => console.log(`${i + 1} - ${u}`));
          menu();
         break;
      case '3':
          const lista = carregarURLs();
         if (lista.length === 0) {
                    console.log('Nenhuma URL para excluir.');
                    menu();
                    break;
                }
                console.log('\n--- URLs Cadastradas ---');
                lista.forEach((u, i) => console.log(`${i + 1} - ${u}`));
                rl.question('Digite o número da URL para excluir: ', num => {
                    const index = parseInt(num) - 1;
                    if (index >= 0 && index < lista.length) {
                        lista.splice(index, 1);
                        salvarURLs(lista);
                        console.log('✅ URL excluída!');
                        eventEmitter.emit('alteracao');
                    } else {
                        console.log('❌ Número inválido.');
                    }
                    menu();
                });
                break;
     case '4':
         console.log('Encerrando...');
         rl.close();
          break;
     default:
        console.log('Opção inválida!');
          menu();
        }
    });
}

eventEmitter.on('alteracao', () => {
    console.log(`(${os.userInfo().username}) Alterou a lista de URLs em: ${new Date().toLocaleString()}`);
});

menu();