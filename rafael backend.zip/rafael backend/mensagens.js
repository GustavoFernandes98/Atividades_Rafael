function mensagemValor() {
    return "Digite o valor em reais (ou 'sair' para encerrar): ";
}

function mensagemMoeda() {
    return "Digite 'USD' para converter para dólar ou 'EUR' para euro: ";
}

function mensagemResultado(valor, moeda) {
    return `Valor convertido: ${valor.toFixed(2)} ${moeda}`;
}

function mensagemSaida() {
    return "Encerrando o programa...";
}

module.exports = {
    mensagemValor,
    mensagemMoeda,
    mensagemResultado,
    mensagemSaida
};

