const readline = require('readline');
const conversor = require('./conversor');
const mensagens = require('./mensagens');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function iniciarConversao() {
    rl.question(mensagens.mensagemValor(), (valor) => {
        if (valor.toLowerCase() === 'sair') {
            console.log(mensagens.mensagemSaida());
            rl.close();
            return;
        }

        const valorNum = parseFloat(valor);
        if (isNaN(valorNum)) {
            console.log("Valor inválido!");
            iniciarConversao();
            return;
        }

        rl.question(mensagens.mensagemMoeda(), (moeda) => {
            let resultado;
            if (moeda.toUpperCase() === 'USD') {
                resultado = conversor.converterParaUSD(valorNum);
                console.log(mensagens.mensagemResultado(resultado, "USD"));
            } else if (moeda.toUpperCase() === 'EUR') {
                resultado = conversor.converterParaEUR(valorNum);
                console.log(mensagens.mensagemResultado(resultado, "EUR"));
            } else {
                console.log("Moeda inválida!");
            }
            iniciarConversao();
        });
    });
}

iniciarConversao();
