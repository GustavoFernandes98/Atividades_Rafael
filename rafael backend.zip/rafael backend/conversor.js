const USD_RATE = 5.41; 
const EUR_RATE = 6.32; 

function converterParaUSD(valorBRL) {
    return valorBRL / USD_RATE;
}

function converterParaEUR(valorBRL) {
    return valorBRL / EUR_RATE;
}

module.exports = { converterParaUSD, converterParaEUR };


